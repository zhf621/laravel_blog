<?php

namespace App\Http\Controllers;


use App\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Session;

class StudentController extends Controller{
    public function test1()
    {
      $student =  DB::select('select * from student');
//        $student = DB::insert('insert into student (name,age ) values (?, ?)', ['hehe1', '18']);
      dd($student);
    }


    public function orm()
    {
        $student =  Student::all();
        dd($student);
    }

    public function orm1()
    {
        $student =  new Student();
        $student->name = 'asd';
        $student->age = 20;
        $student->save();
        dd($student);

    }

    public function section1()
    {
        $name = 'asd';
        $student = Student::get();
        return view('student.section1',
        [
            'name' => $name,
            'studentarr' => $student,
        ]);

    }

    public function request1(Request $request)
    {
        echo $request->input('name');

    }

    public function session(Request $request)
    {
        //$request->session()方法
//        $request->session()->put('key', 'value');
//        echo $request->session()->get('key');

        //session()方法
//        session()->put('key', 'value1');
//        echo  session()->get('key');

        //Session：：方法
//        Session::put('key', 'valuew00');
//        echo Session::get('key');

    }

    public function session1(Request $request)
    {

        return Session::get('message', 'hhhhhhhhhhhh');
//        echo Session::get('key');
    }


    public function response()
    {
//        APP接口
//        $data = [
//            'errCode' => 0,
//            'errMsg' => 'sussess',
//            'data' => 'name',
//        ];
//        return response()->json($data);

//        重定向
//        return redirect('session1');

        return redirect('session1')->with('message', 'miimimi');
    }



    public function activity()
    {
        return 'miimimimi';
    }

    public function activity1()
    {
        return 'hihimimimi';
    }

    public function activity2()
    {
         return 'hihimimimi';
    }




























}

