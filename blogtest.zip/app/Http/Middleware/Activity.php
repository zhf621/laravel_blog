<?php
/**
 * Created by PhpStorm.
 * User: zhf
 * Date: 17-12-29
 * Time: 下午2:05
 */

namespace App\Http\Middleware;


use Closure;

class Activity
{
//    public function handle($request, Closure $next)
//    {
//        if(time() < strtotime('2017-12-20')) {
//            return redirect('activity');
//        }
//        return $next($request);
//    }

    public function handle($request, Closure $next)
    {
        $asd =  $next($request);
        var_dump($asd);
    }



















}
















