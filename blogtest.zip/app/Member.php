<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Member extends Model
{
    public static function getMenber()
    {
        return '1231231231231';

    }

}
