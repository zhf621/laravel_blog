## imooc 轻松学会Laravel-表单篇 类似模板
![](https://github.com/boser90/laravel-form-tpl/raw/master/preview/preview.png)

## 添加表单篇完整代码 laravel版本 5.4.0
	laravel-5.4.0.zip