@extends('layouts')

@section('header')
    miimmim
@stop

@section('content')
   {{--{{ $name }}--}}
    @foreach($studentarr as $asd)
    {{ $asd->name }}
@endforeach
    @stop