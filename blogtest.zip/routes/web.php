<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('member/info', 'MemberController@info');

Route::get('test1', 'StudentController@test1');
Route::any('orm', 'StudentController@orm');
Route::any('orm1', 'StudentController@orm1');
Route::any('section1', 'StudentController@section1');

Route::any('request1', ['uses' => 'StudentController@request1']);

Route::any('response', ['uses' => 'StudentController@response']);


Route::any('activity2', ['uses' => 'StudentController@activity2']);
Route::group(['middleware' => ['web']], function (){
    Route::any('activity', ['uses' => 'StudentController@activity']);
    Route::any('activity1', ['uses' => 'StudentController@activity1']);
});




Route::group(['middleware' => ['web']], function (){
    Route::any('session', ['uses' => 'StudentController@session']);
    Route::any('session1', ['uses' => 'StudentController@session1']);
});





