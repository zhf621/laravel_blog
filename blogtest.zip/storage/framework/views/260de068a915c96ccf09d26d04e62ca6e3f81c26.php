<?php $__env->startSection('header'); ?>
    miimmim
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   
    <?php $__currentLoopData = $studentarr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($asd->name); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>